<h1>index8.phtml</h1>

    <?php $input = 'abcdef'; ?>
    Input  : <?php echo $input; ?><br>
    Output : <?php echo strrev($input); ?>   
    
    <hr>
    
    <?php $input = 'abc'; ?>
    Input  : <?php echo $input; ?><br>
    Output : <?php echo str_repeat($input,2); ?>  
    
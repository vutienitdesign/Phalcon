a:7:{i:0;s:121:"<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
        ";s:6:"header";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:72:"
            <div>Header content - parent - main2.phtml</div>
        ";s:4:"file";s:64:"C:\xampp\htdocs\multiphalcon/chapter05/views/layouts/main2.phtml";s:4:"line";i:10;}}i:1;s:44:"
        
        <hr>
        
        ";s:6:"middle";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:72:"
            <div>Middle content - parent - main2.phtml</div>
        ";s:4:"file";s:64:"C:\xampp\htdocs\multiphalcon/chapter05/views/layouts/main2.phtml";s:4:"line";i:16;}}i:2;s:35:"
        
        <hr> 
        ";s:6:"footer";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:72:"
            <div>Footer content - parent - main2.phtml</div>
        ";s:4:"file";s:64:"C:\xampp\htdocs\multiphalcon/chapter05/views/layouts/main2.phtml";s:4:"line";i:21;}}i:3;s:107:"
        
		
		
		
		<!-- Đây là phần nội dung của tập tin main.phtml -->
</body>
</html>";}
a:7:{i:0;s:15:"<div>
        ";s:6:"header";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:53:"
            <div>Header main4.phtml</div>
        ";s:4:"file";s:64:"C:\xampp\htdocs\multiphalcon/chapter05/views/layouts/main4.phtml";s:4:"line";i:4;}}i:1;s:44:"
        
        <hr>
        
        ";s:6:"middle";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:53:"
            <div>Middle main4.phtml</div>
        ";s:4:"file";s:64:"C:\xampp\htdocs\multiphalcon/chapter05/views/layouts/main4.phtml";s:4:"line";i:10;}}i:2;s:35:"
        
        <hr> 
        ";s:6:"footer";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:53:"
            <div>Footer main4.phtml</div>
        ";s:4:"file";s:64:"C:\xampp\htdocs\multiphalcon/chapter05/views/layouts/main4.phtml";s:4:"line";i:15;}}i:3;s:29:"
        
</div>	
		
		
";}
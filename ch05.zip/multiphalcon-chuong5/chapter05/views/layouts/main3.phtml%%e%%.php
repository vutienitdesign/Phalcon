a:7:{i:0;s:15:"<div>
        ";s:6:"header";s:53:"
            <div>Header main3.phtml</div>
        ";i:1;s:44:"
        
        <hr>
        
        ";s:6:"middle";s:53:"
            <div>Middle main3.phtml</div>
        ";i:2;s:35:"
        
        <hr> 
        ";s:6:"footer";s:53:"
            <div>Footer main4.phtml</div>
        ";i:3;s:29:"
        
</div>	
		
		
";}
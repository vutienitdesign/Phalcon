a:3:{i:0;s:45:"        <h1>main5.phtml</h1>
<div>
        ";s:5:"super";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:50:"
            <h1>super main5.phtml</h1>
        ";s:4:"file";s:64:"C:\xampp\htdocs\multiphalcon/chapter05/views/layouts/main5.phtml";s:4:"line";i:5;}}i:1;s:48:"
        
       
        
</div>	
		
		
";}
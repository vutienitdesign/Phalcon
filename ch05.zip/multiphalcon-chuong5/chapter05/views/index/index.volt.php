<?php
     echo '<h3 style="color:red">'.__FILE__.'</h3>';
<div>
        
            <div>Header index5.phtml</div>
        
        
        <hr>
        
        
            <div>Middle main3.phtml</div>
        
        
        <hr> 
        
            <div>Footer main4.phtml</div>
        
        
</div>	
		
		

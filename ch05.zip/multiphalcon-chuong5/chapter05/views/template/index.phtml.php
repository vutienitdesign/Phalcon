<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
		<div>Header content 8</div>
		<div>Middle content 8</div>
		<div>Footer content 8</div>
		
		<!-- Đây là phần nội dung của tập tin main.phtml -->
</body>
</html>
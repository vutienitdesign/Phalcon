<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
        
            <div>Header content - children - index4.phtml</div>
        
        
        <hr>
        
        
            <div>Middle content - children - index4.phtml</div>
        
        
        <hr> 
        
            <div>Footer content - parent - main2.phtml</div>
        
        
		
		
		
		<!-- Đây là phần nội dung của tập tin main.phtml -->
</body>
</html>
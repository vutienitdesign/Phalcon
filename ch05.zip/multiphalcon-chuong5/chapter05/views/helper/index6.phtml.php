
<html>
<head>
<meta charset="${encoding}">


</head>
<body>
    <h1>javascript</h1>
    
    <?php echo $this->tag->javascriptinclude('http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.js', false); ?>
<?php 
    
   // echo $this->tag->javascriptInclude('http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.js',false);
?>    
</body>
</html>
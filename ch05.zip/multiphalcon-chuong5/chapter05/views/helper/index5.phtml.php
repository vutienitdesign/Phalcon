
<html>
<head>
<meta charset="${encoding}">
    
    <?php echo $this->tag->stylesheetlink('http://fonts.googleapis.com/css?family=Rosario', false); ?>
<?php 
   
    echo $this->tag->stylesheetLink('http://fonts.googleapis.com/css?family=Rosario',false);
?>

</head>
<body>
    <h1>css</h1>
    
    
</body>
</html>
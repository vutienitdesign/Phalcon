
<html>
<head>
<meta charset="${encoding}">
    <?php echo $this->tag->getTitle(); ?>

<?php 
    //echo $this->tag->getTitle();
?>

</head>
<body>
    <h1>set title</h1>
    
</body>
</html>
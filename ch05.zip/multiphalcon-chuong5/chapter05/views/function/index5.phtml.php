
    
    Hello : <?php echo strlen('hello'); ?>
    <hr>
    Word  :      <?php echo str_word_count('wellcome function abc'); ?>

    <?php echo $this->partial('shared/partial1', array('name' => 'peter', 'age' => 20, 'class' => 'phalcon zendvn')); ?>
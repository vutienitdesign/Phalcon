 
<div>
       <h1>Partial1</h1>
       <p>Name : <?php echo $name; ?></p>
       <p>Age : <?php echo $age; ?></p>
       <p>class: <?php echo $class; ?></p>
</div>





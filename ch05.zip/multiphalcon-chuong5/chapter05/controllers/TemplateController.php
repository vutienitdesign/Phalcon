<?php
    namespace Multiphalcon\Chapter05\Controllers;
    class TemplateController extends \Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            echo 'multiphalcon - module Chapter05 - TemplateController - indexAction';
        }
        
        public function index2Action()
        {
            echo 'multiphalcon - module Chapter05 - TemplateController - indexAction';
        }
        
        public function index3Action()
        {
            echo 'multiphalcon - module Chapter05 - TemplateController - indexAction';
        }
        
        public function index4Action()
        {
            echo 'multiphalcon - module Chapter05 - TemplateController - indexAction';
        }
        
        public function index5Action()
        {
            echo 'multiphalcon - module Chapter05 - TemplateController - indexAction';
        }
        
       
        
        
    }
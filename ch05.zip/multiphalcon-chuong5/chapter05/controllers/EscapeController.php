<?php
    namespace Multiphalcon\Chapter05\Controllers;
    class EscapeController extends \Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            
        }
    }
<?php
    namespace Multiphalcon\Chapter05\Controllers;
    class VariableController extends \Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            echo 'multiphalcon - module Chapter05 - VariableController - indexAction';
        }
        
        //toán tử số học
        public function index2Action()
        {
            
        }
        
        //toán tử gán
        public function index3Action()
        {
        
        }
        
        //toán tử so sánh
        public function index4Action()
        {
        
        }
        
        //toán tử logic
        public function index5Action()
        {
        
        }
        
        //toán tử điều kiện
        public function index6Action()
        {
        
        }
        
        //check
        public function index7Action()
        {
        
        }
        
        
        
        
        
    }
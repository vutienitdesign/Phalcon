<?php
    namespace Multiphalcon\Chapter05\Controllers;
    class FunctionController extends \Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            echo 'multiphalcon - module Chapter05 - FunctionController - indexAction';
        }
        
        public function index2Action()
        {
            echo 'multiphalcon - module Chapter05 - FunctionController - index2Action';
        }
        
        public function index3Action()
        {
            echo 'multiphalcon - module Chapter05 - FunctionController - index3Action';
        }
        
        public function index4Action()
        {
            echo 'multiphalcon - module Chapter05 - FunctionController - index4Action';
        }
        
        public function index5Action()
        {
            echo 'multiphalcon - module Chapter05 - FunctionController - index5Action';
        }
        
        
    }
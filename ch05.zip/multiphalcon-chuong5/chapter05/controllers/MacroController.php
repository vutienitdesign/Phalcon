<?php
    namespace Multiphalcon\Chapter05\Controllers;
    class MacroController extends \Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            echo 'multiphalcon - module Chapter05 - MacroController - indexAction';
        }
        
        public function index2Action()
        {
            
        }
        
        public function index3Action()
        {
        
        }
    }
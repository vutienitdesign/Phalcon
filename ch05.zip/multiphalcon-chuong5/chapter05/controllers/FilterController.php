<?php
    namespace Multiphalcon\Chapter05\Controllers;
    class FilterController extends \Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            echo 'multiphalcon - module Chapter05 - FilterController - indexAction';
        }
        
        public function index2Action()
        {
           
        }
        
        public function index3Action()
        {
             
        }
        
        public function index4Action()
        {
             
        }
        
        public function index5Action()
        {
             
        }
        
        public function index6Action()
        {
             
        }
        
        public function index7Action()
        {
             
        }
        
        public function index8Action()
        {
             
        }
        
        
    }
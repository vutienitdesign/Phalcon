<?php
    //đường dẫn đến ứng dụng multiphalcon
    define('APPLICATION_PATH', __DIR__);
    
    //đường dẫn đến thư mục vendor
    define('LIBRARY_PATH', APPLICATION_PATH.'/vendor');
    
    //đường dẫn cho HTMLPURIFIER_PREFIX
    define('HTMLPURIFIER_PREFIX', LIBRARY_PATH);
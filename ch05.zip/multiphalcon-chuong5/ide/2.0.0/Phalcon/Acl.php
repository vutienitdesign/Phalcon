<?php

namespace Phalcon;

abstract class Acl
{

    const ALLOW = 1;


    const DENY = 0;


}

<?php

namespace Phalcon\Events;

class Exception extends \Phalcon\Exception
{

}

<?php

namespace Phalcon\Forms\Element;

class Password extends \Phalcon\Forms\Element implements \Phalcon\Forms\ElementInterface
{

    /**
     * Renders the element widget returning html
     *
     * @param mixed $attributes 
     * @param array $$attributes 
     * @return string 
     */
	public function render($attributes = null) {}

}

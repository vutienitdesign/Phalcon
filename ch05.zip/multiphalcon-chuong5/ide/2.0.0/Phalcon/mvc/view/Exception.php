<?php

namespace Phalcon\Mvc\View;

class Exception extends \Phalcon\Exception
{

}

<?php

namespace Phalcon\Mvc\Application;

class Exception extends \Phalcon\Exception
{

}

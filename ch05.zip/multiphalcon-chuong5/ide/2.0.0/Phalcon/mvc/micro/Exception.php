<?php

namespace Phalcon\Mvc\Micro;

class Exception extends \Phalcon\Exception
{

}

<?php

namespace Phalcon\Mvc\Model;

class Exception extends \Phalcon\Exception
{

}

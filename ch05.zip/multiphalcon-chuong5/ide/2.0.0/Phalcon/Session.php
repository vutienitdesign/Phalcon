<?php

namespace Phalcon;

abstract class Session
{

}

<?php

namespace Phalcon\Cli;

class Task extends \Phalcon\Di\Injectable
{

    /**
     * Phalcon\Cli\Task constructor
     */
	public final function __construct() {}

}

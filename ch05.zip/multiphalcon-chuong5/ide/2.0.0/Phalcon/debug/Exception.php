<?php

namespace Phalcon\Debug;

class Exception extends \Phalcon\Exception
{

}

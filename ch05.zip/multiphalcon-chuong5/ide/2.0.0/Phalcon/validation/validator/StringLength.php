<?php

namespace Phalcon\Validation\Validator;

class StringLength extends \Phalcon\Validation\Validator implements \Phalcon\Validation\ValidatorInterface
{

    /**
     * Executes the validation
     *
     * @param \Phalcon\Validation $validation 
     * @param string $field 
     * @return boolean 
     */
	public function validate(\Phalcon\Validation $validation, $field) {}

}

<?php

namespace Phalcon\Di;

class Exception extends \Phalcon\Exception
{

}

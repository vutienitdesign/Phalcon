<?php

namespace Phalcon\Translate;

class Exception extends \Phalcon\Exception
{

}

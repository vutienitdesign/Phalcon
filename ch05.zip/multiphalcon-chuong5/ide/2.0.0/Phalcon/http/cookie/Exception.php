<?php

namespace Phalcon\Http\Cookie;

class Exception extends \Phalcon\Exception
{

}

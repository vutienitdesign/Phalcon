<?php

namespace Phalcon\Db\Dialect;

class Oracle extends \Phalcon\Db\Dialect
{

    protected $_escapeChar = "";


}

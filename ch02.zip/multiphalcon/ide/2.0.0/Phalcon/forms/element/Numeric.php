<?php

namespace Phalcon\Forms\Element;

class Numeric extends \Phalcon\Forms\Element implements \Phalcon\Forms\ElementInterface
{

    /**
     * Renders the element widget returning html
     *
     * @param mixed $attributes 
     * @param array $$attributes 
     * @return string 
     */
	public function render($attributes = null) {}

}

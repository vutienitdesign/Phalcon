<?php

namespace Phalcon\Security;

class Exception extends \Phalcon\Exception
{

}

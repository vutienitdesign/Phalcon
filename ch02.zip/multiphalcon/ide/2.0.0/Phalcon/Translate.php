<?php

namespace Phalcon;

abstract class Translate
{

}

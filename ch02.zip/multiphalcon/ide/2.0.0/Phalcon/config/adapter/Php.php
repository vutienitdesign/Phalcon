<?php

namespace Phalcon\Config\Adapter;

class Php extends \Phalcon\Config
{

    /**
     * Phalcon\Config\Adapter\Php constructor
     *
     * @param string $filePath 
     */
	public function __construct($filePath) {}

}

<?php

namespace Phalcon\Config\Adapter;

class Yaml extends \Phalcon\Config
{

    /**
     * Phalcon\Config\Adapter\Yaml constructor
     *
     * @throws \Phalcon\Config\Exception
     * @param string $filePath 
     * @param array $callbacks 
     */
	public function __construct($filePath, $callbacks = null) {}

}

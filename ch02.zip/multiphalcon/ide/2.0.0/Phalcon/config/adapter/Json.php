<?php

namespace Phalcon\Config\Adapter;

class Json extends \Phalcon\Config
{

    /**
     * Phalcon\Config\Adapter\Json constructor
     *
     * @param string $filePath 
     */
	public function __construct($filePath) {}

}

<?php

namespace Phalcon\Cli\Router;

class Exception extends \Phalcon\Exception
{

}

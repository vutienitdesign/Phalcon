<?php

namespace Phalcon\Cli\Console;

class Exception extends \Phalcon\Exception
{

}

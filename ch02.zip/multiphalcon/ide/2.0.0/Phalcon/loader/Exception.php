<?php

namespace Phalcon\Loader;

class Exception extends \Phalcon\Exception
{

}

<?php

namespace Phalcon\Flash;

class Exception extends \Phalcon\Exception
{

}

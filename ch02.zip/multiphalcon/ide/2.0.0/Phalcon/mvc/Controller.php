<?php

namespace Phalcon\Mvc;

abstract class Controller extends \Phalcon\Di\Injectable
{

    /**
     * Phalcon\Mvc\Controller constructor
     */
	public final function __construct() {}

}

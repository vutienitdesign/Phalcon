<?php

namespace Phalcon\Mvc;

interface ControllerInterface
{

}

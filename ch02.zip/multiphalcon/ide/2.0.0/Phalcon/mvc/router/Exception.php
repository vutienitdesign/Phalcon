<?php

namespace Phalcon\Mvc\Router;

class Exception extends \Phalcon\Exception
{

}

<?php

namespace Phalcon\Assets\Filters;

class Jsmin implements \Phalcon\Assets\FilterInterface
{

    /**
     * Filters the content using JSMIN
     *
     * @param string $content 
     * @return string 
     */
	public function filter($content) {}

}

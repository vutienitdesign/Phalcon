<?php

namespace Phalcon\Assets\Filters;

class Cssmin implements \Phalcon\Assets\FilterInterface
{

    /**
     * Filters the content using CSSMIN
     *
     * @param string $content 
     * @return string 
     */
	public function filter($content) {}

}

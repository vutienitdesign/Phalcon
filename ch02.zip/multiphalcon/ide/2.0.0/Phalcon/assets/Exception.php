<?php

namespace Phalcon\Assets;

class Exception extends \Phalcon\Exception
{

}

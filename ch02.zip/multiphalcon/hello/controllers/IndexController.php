<?php
    namespace Multiphalcon\Hello\Controllers;
    class IndexController extends \Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            echo 'multiphalcon - module hello - indexController - indexAction';
        }
    }
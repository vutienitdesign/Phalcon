<?php
$loader = new \Phalcon\Loader();
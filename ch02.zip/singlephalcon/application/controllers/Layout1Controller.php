<?php
    use Phalcon\Mvc\View;
class Layout1Controller extends Phalcon\Mvc\Controller
    {
        public function index1Action()
        {
           $this->view->setTemplateAfter('after');
           $this->view->setTemplateBefore('before');
        }
        
        public function index2Action()
        {
            
        }
        
        public function index3Action()
        {
            $this->view->setTemplateAfter('after');
            $this->view->setTemplateBefore('before');
            //thiet lap muc layout cao nhat after template
           // $this->view->setRenderLevel(View::LEVEL_AFTER_TEMPLATE);
           
            //thiet lap muc layout cao nhat controller layout
            $this->view->setRenderLevel(View::LEVEL_LAYOUT);
            
            //thiet lap muc layout cao nhat before template
            $this->view->setRenderLevel(View::LEVEL_BEFORE_TEMPLATE);
            
            //thiet lap muc layout cao nhat action layout
            $this->view->setRenderLevel(View::LEVEL_ACTION_VIEW);
            
            //thiet lap muc layout cao nhat no render
            $this->view->setRenderLevel(View::LEVEL_NO_RENDER);
        }
        
        public function index4Action()
        {
            $this->view->setTemplateAfter('after');
            $this->view->setTemplateBefore('before');
            
            //tat di giao dien o cap action view
            $this->view->disableLevel(View::LEVEL_ACTION_VIEW);
            
            //tat di giao dien o cap before template
            $this->view->disableLevel(View::LEVEL_BEFORE_TEMPLATE);
            
            //tat di giao dien o cap controller layout
            $this->view->disableLevel(View::LEVEL_LAYOUT);
            
            //tat di giao dien o cap after template
            $this->view->disableLevel(View::LEVEL_AFTER_TEMPLATE);
            
            //tat di giao dien o cap main layout
            $this->view->disableLevel(View::LEVEL_MAIN_LAYOUT);
        }
        
        public function index5Action()
        {
           $this->view->setRenderLevel(View::LEVEL_ACTION_VIEW);
        }
        
        public function index6Action()
        {
            $this->view->setRenderLevel(View::LEVEL_ACTION_VIEW);
        }
        
        public function index7Action()
        {
            $this->view->setRenderLevel(View::LEVEL_ACTION_VIEW);
        }
        
        public function index8Action()
        {
            $this->view->setRenderLevel(View::LEVEL_ACTION_VIEW);
        }
        
        
        
        
        
        
        
        
        
        
        
    }
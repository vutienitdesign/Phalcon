<?php
    class ControlController extends Phalcon\Mvc\Controller
    {
//         public function __construct()
//         {
            
//         }

        public function initialize()
        {
            echo '<div>'.__FUNCTION__.'</div>';
        }
        
        public function indexAction($name)
        {
            echo 'hello : '.$name;
        }
        
        public function index1Action($name = 'join')
        {
            echo 'hello : '.$name;
        }
        
        //truyen nhieu bien cho action
        public function index2Action($name,$age, $color)
        {
            echo 'hello : '.$name;
            echo '<br>age : '.$age;
            echo '<br>color : '.$color;
            
        }
        
        public function index3Action()
        {
           echo __FUNCTION__;
        
        }
    }
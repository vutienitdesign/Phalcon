<?php
    class ShowController extends Phalcon\Mvc\Controller
    {
        public function indexAction()
        {
            echo __FILE__;
        }
        
        public function editAction()
        {
            echo __FUNCTION__;
            $this->view->disable();
        }
        
        public function index2Action()
        {
            $name = 'nguyễn văn a';
            //$this->view->setVar('username', $name);
            //truyền một chuổi ra ngoài view
            
//             $this->view->setVar('username', 'nguyễn văn b');

            //truyền một mảng ra ngoài view
            $arrinfo = [
                'name'          =>  'student1',
                'birthday'      =>  1992,
                'color-hair'    =>  'yellow'  
            ];
            
            $this->view->setVar('info', $arrinfo);
        }
        
        public function index3Action()
        {
            
            $arrinfo = [
                'name'          =>  'student1',
                'birthday'      =>  1992,
                'color-hair'    =>  'yellow'
            ];
            
            $this->view->info = $arrinfo;
        
        }
        
        public function index4Action()
        {
        
            $this->view->pick('tamp/pickview');
        
        }
        
        public function index5Action($type)
        {
            if($type == 'pickview')
            {
                $this->view->pick('tamp/pickview');
            }
           
        
        }
               
        
        
        
        
        
        
        
        
        
        
    }
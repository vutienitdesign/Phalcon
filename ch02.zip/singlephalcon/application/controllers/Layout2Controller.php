<?php
    class Layout2Controller extends Phalcon\Mvc\Controller
    {
        public function index1Action()
        {
           
        }
        
        public function index2Action()
        {
            
        }
    }
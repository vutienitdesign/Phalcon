<?php

namespace Phalcon\Cli\Dispatcher;

class Exception extends \Phalcon\Exception
{

}

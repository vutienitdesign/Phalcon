<?php

namespace Phalcon\Validation;

class Exception extends \Phalcon\Exception
{

}

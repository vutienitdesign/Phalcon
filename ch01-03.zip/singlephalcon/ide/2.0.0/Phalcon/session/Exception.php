<?php

namespace Phalcon\Session;

class Exception extends \Phalcon\Exception
{

}

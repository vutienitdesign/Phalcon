<?php

namespace Phalcon\Tag;

class Exception extends \Phalcon\Exception
{

}

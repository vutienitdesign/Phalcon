<?php

namespace Phalcon\Mvc\Model;

class ValidationFailed extends \Phalcon\Mvc\Model\Exception
{

    protected $_model;


    protected $_messages;


}

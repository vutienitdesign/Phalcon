<?php

namespace Phalcon\Mvc\Model\Validator;

class Uniqueness extends \Phalcon\Mvc\Model\Validator implements \Phalcon\Mvc\Model\ValidatorInterface
{

    /**
     * Executes the validator
     *
     * @param \Phalcon\Mvc\ModelInterface $record 
     * @return boolean 
     */
	public function validate(\Phalcon\Mvc\ModelInterface $record) {}

}

<?php

namespace Phalcon\Di;

class FactoryDefault extends \Phalcon\Di
{

    /**
     * Phalcon\Di\FactoryDefault constructor
     */
	public function __construct() {}

}

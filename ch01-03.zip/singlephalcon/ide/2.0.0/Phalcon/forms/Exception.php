<?php

namespace Phalcon\Forms;

class Exception extends \Phalcon\Exception
{

}

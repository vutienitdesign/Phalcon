<?php

namespace Phalcon\Cache;

class Exception extends \Phalcon\Exception
{

}

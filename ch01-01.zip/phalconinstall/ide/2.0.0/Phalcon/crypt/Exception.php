<?php

namespace Phalcon\Crypt;

class Exception extends \Phalcon\Exception
{

}

<?php

namespace Phalcon\Di\FactoryDefault;

class Cli extends \Phalcon\Di\FactoryDefault
{

    /**
     * Phalcon\Di\FactoryDefault\CLI constructor
     */
	public function __construct() {}

}

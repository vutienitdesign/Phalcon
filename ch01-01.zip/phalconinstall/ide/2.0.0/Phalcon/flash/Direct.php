<?php

namespace Phalcon\Flash;

class Direct extends \Phalcon\Flash implements \Phalcon\FlashInterface
{

    /**
     * Outputs a message
     *
     * @param string $type 
     * @param string|array $message 
     * @return string 
     */
	public function message($type, $message) {}

}

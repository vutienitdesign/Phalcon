<?php

namespace Phalcon\Acl;

class Exception extends \Phalcon\Exception
{

}

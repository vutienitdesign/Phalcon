<?php

namespace Phalcon\Mvc\User;

class Component extends \Phalcon\Di\Injectable
{

}

<?php

namespace Phalcon\Config;

class Exception extends \Phalcon\Exception
{

}

<?php
    echo '<pre>';
        print_r(get_loaded_extensions());
    echo '</pre>';
    
    
    